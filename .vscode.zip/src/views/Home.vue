<template>
    <Content />
</template>

<script setup>
import Content from '../components/Content.vue'

</script>

<style lang="scss" scoped>

</style>